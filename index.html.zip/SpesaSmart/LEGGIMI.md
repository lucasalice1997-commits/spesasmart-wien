# SpesaSmart: attivare l'aggiornamento automatico (una volta sola)

Dopo questi passaggi non devi fare piu' nulla: ogni settimana il sistema cerca i volantini, li legge
e aggiorna l'app da solo. I passaggi sono 5 e richiedono circa 20 minuti.
(I nomi dei menu di GitHub, Netlify e Anthropic possono cambiare leggermente.)

## Come funziona
1. GitHub Actions parte lunedi', mercoledi', giovedi' e venerdi' alle 05:00 UTC (06:00 o 07:00 a Vienna).
2. Lo script legge le pagine ufficiali di Billa, Hofer, Penny e Norma (rispettando robots.txt), e Claude estrae le offerte.
3. Aggiorna `offers.json` e lo salva nel repository. Netlify ripubblica l'app.
4. L'app mostra solo le offerte attive nel giorno in cui la apri.
5. Se qualcosa non funziona o i dati hanno piu' di 10 giorni, GitHub ti manda un'email.

## Passo 1: repository privato su GitHub
Crea un repository **privato** chiamato `spesasmart` e carica tutto il contenuto di questa cartella,
compresa la cartella nascosta `.github`. Se dal sito non riesci a caricarla, da terminale:

    git init && git add -A && git commit -m "Primo caricamento"
    git branch -M main
    git remote add origin https://github.com/TUO-UTENTE/spesasmart.git
    git push -u origin main

## Passo 2: chiave API Anthropic (con limite di spesa)
1. Su https://console.anthropic.com crea una chiave API dedicata a questo progetto.
2. Imposta un limite di spesa mensile basso (consiglio 5 USD, poi lo regoli).
3. **Non incollare la chiave in chat, nei file o nel codice.** Va solo nel passo successivo.

## Passo 3: salvare la chiave come segreto
Su GitHub, nel repository: Settings, Secrets and variables, Actions, New repository secret.
Nome: `ANTHROPIC_API_KEY`. Valore: la chiave. Salva.

## Passo 4: primo avvio e controllo
Vai su Actions, scegli "Aggiorna offerte", clicca Run workflow.
- Verde: nel repository trovi `offers.json` aggiornato.
- Rosso: apri l'esecuzione e incollami l'errore (senza chiavi), lo sistemo.
Spar e Lidl non sono automatici: se vuoi le loro offerte, carica i PDF nella cartella `volantini/`;
vengono letti e cancellati da soli.

## Passo 5: pubblicare l'app
Su https://app.netlify.com: Add new site, Import from Git, scegli il repository, build command vuoto,
publish directory `.`. Poi apri l'indirizzo dal telefono e installala:
- iPhone (Safari): Condividi, "Aggiungi alla schermata Home".
- Android (Chrome): menu, "Installa app".

## Manutenzione e sicurezza
- Costi: lo script legge al massimo 60 documenti per esecuzione (tetto in `MAX_JOBS`); controlla la spesa sulla console Anthropic dopo la prima settimana.
- Se una catena cambia il suo sito, quella catena smette di aggiornarsi e GitHub ti avvisa; l'app non usa mai offerte scadute.
- Se GitHub dovesse sospendere le esecuzioni programmate per inattivita', riattivale da Actions con un clic.
- L'uso e' pensato per un'app personale. Per distribuirla ad altri, controlla prima i termini d'uso delle catene.
